/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package codigo;

/**
 *
 * @author Charly Ponce
 */
public enum Tokens
{
	reservada, litcad, litcar, id, nume, numf, salto, agrupacion, aritmetico, logico, relacional, meniq, mayiq, dif,
	igual, coma, puntos, asignacion, finSentencia, ERROR
}
