/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package codigo;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Reader;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileFilter;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;

public class FrmPrincipal extends javax.swing.JFrame
{
	private String pila_aux = "";
	private String com = "";
	private String textoPila = "", textoEnt = "", textoAccion = "", textoConsola = "";
	private String msj_error = "";
	private Sintactico objs;
	private int lineaerror = 0;
	int tamanoFont = 14;
	Font tipodeletra = new Font("Poppins", Font.PLAIN, tamanoFont);
	Font tipodeletraT = new Font("Poppins", Font.BOLD, tamanoFont + 1);
	Color fontColor = Color.white;
	Color colorTF = new Color(22, 27, 33);
	Color colorBG = new Color(13, 17, 25);
	Color colorBG2 = new Color(22, 26, 34);
	int minmax = 0;
	Archivo files;
	int acolor = 0;
	Image icon = new ImageIcon(getClass().getResource("/Icons/saturn_1.png")).getImage();
	JFrame f = new JFrame();
	String hola = "Poppins";

	NumeroLinea numLinea;
	NumeroLinea numLineaConsole;
	NumeroLinea numLineaTabla;
	DefaultTableModel dtm;
	Object[] o = new Object[3];

	public FrmPrincipal()
	{
		initComponents();
		this.setLocationRelativeTo(null);
		this.setExtendedState(this.MAXIMIZED_BOTH);
		numLinea = new NumeroLinea(txtEntrada);
		jScrollPane2.setRowHeaderView(numLinea);
		numLineaConsole = new NumeroLinea(txtResultado);
		jScrollPane1.setRowHeaderView(numLineaConsole);
		dtm = (DefaultTableModel) tablaS.getModel();

	}

	@SuppressWarnings("unchecked")
	// <editor-fold defaultstate="collapsed" desc="Generated
	// Code">//GEN-BEGIN:initComponents
	private void initComponents()
	{

		btnAnalizar = new javax.swing.JButton();
		jScrollPane3 = new javax.swing.JScrollPane();
		txtPila1 = new javax.swing.JTextArea();
		jScrollPane6 = new javax.swing.JScrollPane();
		tablaS = new javax.swing.JTable();
		jFileChooser1 = new javax.swing.JFileChooser();
		jPanel1 = new javax.swing.JPanel();
		jPanel5 = new javax.swing.JPanel();
		nuevo = new javax.swing.JPanel();
		jLabel14 = new javax.swing.JLabel();
		jLabel1 = new javax.swing.JLabel();
		abrir = new javax.swing.JPanel();
		jLabel15 = new javax.swing.JLabel();
		jLabel6 = new javax.swing.JLabel();
		guardar = new javax.swing.JPanel();
		jLabel16 = new javax.swing.JLabel();
		jLabel7 = new javax.swing.JLabel();
		ejecutar = new javax.swing.JPanel();
		jLabel8 = new javax.swing.JLabel();
		jLabel9 = new javax.swing.JLabel();
		jPanel2 = new javax.swing.JPanel();
		jPanel13 = new javax.swing.JPanel();
		jLabel3 = new javax.swing.JLabel();
		jPanel3 = new javax.swing.JPanel();
		jTabbedPane1 = new javax.swing.JTabbedPane();
		jScrollPane2 = new javax.swing.JScrollPane();
		txtEntrada = new javax.swing.JTextArea();
		jTabbedPane2 = new javax.swing.JTabbedPane();
		jScrollPane1 = new javax.swing.JScrollPane();
		txtResultado = new javax.swing.JTextArea();
		jScrollPane7 = new javax.swing.JScrollPane();
		jPanel4 = new javax.swing.JPanel();
		jPanel7 = new javax.swing.JPanel();
		jPanel10 = new javax.swing.JPanel();
		jLabel2 = new javax.swing.JLabel();
		txtPila = new javax.swing.JTextArea();
		jPanel8 = new javax.swing.JPanel();
		jPanel11 = new javax.swing.JPanel();
		jLabel4 = new javax.swing.JLabel();
		txtEnt = new javax.swing.JTextArea();
		jPanel9 = new javax.swing.JPanel();
		jPanel12 = new javax.swing.JPanel();
		jLabel5 = new javax.swing.JLabel();
		txtAccion = new javax.swing.JTextArea();
		jScrollPane4 = new javax.swing.JScrollPane();
		txtConsola = new javax.swing.JTextArea();

		btnAnalizar.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
		btnAnalizar.setText("Analizar");
		btnAnalizar.addActionListener(new java.awt.event.ActionListener()
		{
			public void actionPerformed(java.awt.event.ActionEvent evt)
			{
				btnAnalizarActionPerformed(evt);
			}
		});

		txtPila1.setColumns(20);
		txtPila1.setFont(tipodeletra);
		txtPila1.setRows(5);
		jScrollPane3.setViewportView(txtPila1);

		tablaS.setFont(tipodeletra);
		tablaS.setModel(new javax.swing.table.DefaultTableModel(new Object[][] {

		}, new String[] { "Pila", "Entrada", "Accion" }));
		jScrollPane6.setViewportView(tablaS);

		jFileChooser1.addActionListener(new java.awt.event.ActionListener()
		{
			public void actionPerformed(java.awt.event.ActionEvent evt)
			{
				jFileChooser1ActionPerformed(evt);
			}
		});

		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
		setIconImage(icon);
		setSize(new java.awt.Dimension(1053, 695));

		jPanel1.setBackground(colorBG2);
		jPanel1.setPreferredSize(new java.awt.Dimension(60, 630));
		jPanel1.setLayout(new javax.swing.BoxLayout(jPanel1, javax.swing.BoxLayout.Y_AXIS));

		jPanel5.setBackground(new java.awt.Color(22, 26, 34));
		jPanel5.setOpaque(false);

		jPanel5.setPreferredSize(new java.awt.Dimension(50, 350));
		java.awt.FlowLayout flowLayout6 = new java.awt.FlowLayout();
		flowLayout6.setAlignOnBaseline(true);
		jPanel5.setLayout(flowLayout6);

		nuevo.setBackground(colorBG2);
		nuevo.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
		nuevo.setMinimumSize(new java.awt.Dimension(26, 26));
		nuevo.setPreferredSize(new java.awt.Dimension(50, 50));
		nuevo.addMouseListener(new java.awt.event.MouseAdapter()
		{
			public void mouseClicked(java.awt.event.MouseEvent evt)
			{
				nuevoMouseClicked(evt);
			}

			public void mouseEntered(java.awt.event.MouseEvent evt)
			{
				nuevoMouseEntered(evt);
			}

			public void mouseExited(java.awt.event.MouseEvent evt)
			{
				nuevoMouseExited(evt);
			}
		});
		nuevo.setLayout(new java.awt.BorderLayout());

		jLabel14.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
		jLabel14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icons/add.png"))); // NOI18N
		jLabel14.setToolTipText("");
		nuevo.add(jLabel14, java.awt.BorderLayout.CENTER);

		jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
		jLabel1.setForeground(new java.awt.Color(255, 255, 255));
		jLabel1.setText("  CREAR");
		nuevo.add(jLabel1, java.awt.BorderLayout.PAGE_END);

		jPanel5.add(nuevo);

		abrir.setBackground(colorBG2);
		abrir.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
		abrir.setPreferredSize(new java.awt.Dimension(50, 50));
		abrir.addMouseListener(new java.awt.event.MouseAdapter()
		{
			public void mouseClicked(java.awt.event.MouseEvent evt)
			{
				abrirMouseClicked(evt);
			}

			public void mouseEntered(java.awt.event.MouseEvent evt)
			{
				abrirMouseEntered(evt);
			}

			public void mouseExited(java.awt.event.MouseEvent evt)
			{
				abrirMouseExited(evt);
			}
		});
		abrir.setLayout(new java.awt.BorderLayout());

		jLabel15.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
		jLabel15.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icons/open.png"))); // NOI18N
		abrir.add(jLabel15, java.awt.BorderLayout.CENTER);

		jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
		jLabel6.setForeground(new java.awt.Color(255, 255, 255));
		jLabel6.setText("  ABRIR");
		abrir.add(jLabel6, java.awt.BorderLayout.PAGE_END);

		jPanel5.add(abrir);

		guardar.setBackground(colorBG2);
		guardar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
		guardar.setFocusCycleRoot(true);
		guardar.setPreferredSize(new java.awt.Dimension(60, 50));
		guardar.addMouseListener(new java.awt.event.MouseAdapter()
		{
			public void mouseClicked(java.awt.event.MouseEvent evt)
			{
				guardarMouseClicked(evt);
			}

			public void mouseEntered(java.awt.event.MouseEvent evt)
			{
				guardarMouseEntered(evt);
			}

			public void mouseExited(java.awt.event.MouseEvent evt)
			{
				guardarMouseExited(evt);
			}
		});
		guardar.setLayout(new java.awt.BorderLayout());

		jLabel16.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
		jLabel16.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icons/save.png"))); // NOI18N
		guardar.add(jLabel16, java.awt.BorderLayout.CENTER);

		jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
		jLabel7.setForeground(new java.awt.Color(255, 255, 255));
		jLabel7.setText("GUARDAR");
		guardar.add(jLabel7, java.awt.BorderLayout.PAGE_END);

		jPanel5.add(guardar);

		ejecutar.setBackground(colorBG2);
		ejecutar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
		ejecutar.setPreferredSize(new java.awt.Dimension(60, 50));
		ejecutar.addMouseListener(new java.awt.event.MouseAdapter()
		{
			public void mouseClicked(java.awt.event.MouseEvent evt)
			{
				ejecutarMouseClicked(evt);
			}

			public void mouseEntered(java.awt.event.MouseEvent evt)
			{
				ejecutarMouseEntered(evt);
			}

			public void mouseExited(java.awt.event.MouseEvent evt)
			{
				ejecutarMouseExited(evt);
			}
		});
		ejecutar.setLayout(new java.awt.BorderLayout());

		jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
		jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icons/run1.png"))); // NOI18N
		ejecutar.add(jLabel8, java.awt.BorderLayout.CENTER);

		jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
		jLabel9.setForeground(new java.awt.Color(255, 255, 255));
		jLabel9.setText(" EJECUTAR");
		jLabel9.setMinimumSize(new java.awt.Dimension(56, 56));
		ejecutar.add(jLabel9, java.awt.BorderLayout.PAGE_END);

		jPanel5.add(ejecutar);

		jPanel1.add(jPanel5);

		getContentPane().add(jPanel1, java.awt.BorderLayout.LINE_START);

		jPanel2.setBackground(new java.awt.Color(0, 0, 204));
		jPanel2.setPreferredSize(new java.awt.Dimension(1000, 55));
		jPanel2.setLayout(new javax.swing.BoxLayout(jPanel2, javax.swing.BoxLayout.LINE_AXIS));

		jPanel13.setBackground(new java.awt.Color(0, 51, 204));
		jPanel13.setOpaque(false);
		jPanel13.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 10, 10));

		jLabel3.setFont(new java.awt.Font("Bookman Old Style", 1, 24)); // NOI18N
		jLabel3.setForeground(new java.awt.Color(255, 255, 255));
		jLabel3.setText("COPILADOR (ANALIZADOR LEXICO Y SINTACTICO)");
		jLabel3.setAlignmentX(20.0F);
		jPanel13.add(jLabel3);

		jPanel2.add(jPanel13);

		getContentPane().add(jPanel2, java.awt.BorderLayout.PAGE_START);

		jPanel3.setBackground(colorBG);
		jPanel3.setLayout(new javax.swing.BoxLayout(jPanel3, javax.swing.BoxLayout.Y_AXIS));

		jTabbedPane1.setFont(new java.awt.Font("Poppins", 0, 14)); // NOI18N

		txtEntrada.setBackground(colorTF);
		txtEntrada.setColumns(20);
		txtEntrada.setFont(tipodeletra);
		txtEntrada.setForeground(fontColor);
		txtEntrada.setRows(5);
		txtEntrada.setSelectionColor(new java.awt.Color(0, 204, 204));
		jScrollPane2.setViewportView(txtEntrada);

		jTabbedPane1.addTab("unnamed.jdi", jScrollPane2);

		jPanel3.add(jTabbedPane1);

		jTabbedPane2.setFont(tipodeletra);
		jTabbedPane2.setMaximumSize(new java.awt.Dimension(32767, 500));
		jTabbedPane2.setPreferredSize(new java.awt.Dimension(100, 280));

		txtResultado.setBackground(colorTF);
		txtResultado.setColumns(20);
		txtResultado.setFont(tipodeletra);
		txtResultado.setForeground(fontColor);
		txtResultado.setRows(5);
		jScrollPane1.setViewportView(txtResultado);

		jTabbedPane2.addTab("Componentes", jScrollPane1);

		jPanel4.setLayout(new javax.swing.BoxLayout(jPanel4, javax.swing.BoxLayout.LINE_AXIS));

		jPanel7.setLayout(new javax.swing.BoxLayout(jPanel7, javax.swing.BoxLayout.Y_AXIS));

		jPanel10.setBackground(new java.awt.Color(204, 204, 0));
		jPanel10.setBorder(javax.swing.BorderFactory.createEtchedBorder());

		jLabel2.setFont(new java.awt.Font("Bookman Old Style", 1, 14)); // NOI18N
		jLabel2.setText("PILA");
		jLabel2.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
		jPanel10.add(jLabel2);

		jPanel7.add(jPanel10);

		txtPila.setBackground(colorTF);
		txtPila.setColumns(20);
		txtPila.setFont(tipodeletra);
		txtPila.setForeground(fontColor);
		txtPila.setRows(5);
		jPanel7.add(txtPila);

		jPanel4.add(jPanel7);

		jPanel8.setLayout(new javax.swing.BoxLayout(jPanel8, javax.swing.BoxLayout.Y_AXIS));

		jPanel11.setBackground(new java.awt.Color(204, 204, 0));
		jPanel11.setBorder(javax.swing.BorderFactory.createEtchedBorder());

		jLabel4.setFont(new java.awt.Font("Bookman Old Style", 1, 14)); // NOI18N
		jLabel4.setText("ENTRADA");
		jLabel4.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
		jPanel11.add(jLabel4);

		jPanel8.add(jPanel11);

		txtEnt.setBackground(colorTF);
		txtEnt.setColumns(20);
		txtEnt.setFont(tipodeletra);
		txtEnt.setForeground(fontColor);
		txtEnt.setRows(5);
		jPanel8.add(txtEnt);

		jPanel4.add(jPanel8);

		jPanel9.setLayout(new javax.swing.BoxLayout(jPanel9, javax.swing.BoxLayout.Y_AXIS));

		jPanel12.setBackground(new java.awt.Color(204, 204, 0));
		jPanel12.setBorder(javax.swing.BorderFactory.createEtchedBorder());

		jLabel5.setFont(new java.awt.Font("Bookman Old Style", 1, 14)); // NOI18N
		jLabel5.setText("ACCION");
		jLabel5.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
		jPanel12.add(jLabel5);

		jPanel9.add(jPanel12);

		txtAccion.setBackground(colorTF);
		txtAccion.setColumns(20);
		txtAccion.setFont(tipodeletra);
		txtAccion.setForeground(fontColor);
		txtAccion.setRows(5);
		jPanel9.add(txtAccion);

		jPanel4.add(jPanel9);

		jScrollPane7.setViewportView(jPanel4);

		jTabbedPane2.addTab("Pila", jScrollPane7);

		txtConsola.setBackground(colorTF);
		txtConsola.setColumns(20);
		txtConsola.setFont(tipodeletra);
		txtConsola.setForeground(fontColor);
		txtConsola.setRows(5);
		jScrollPane4.setViewportView(txtConsola);

		jTabbedPane2.addTab("Consola", jScrollPane4);

		jPanel3.add(jTabbedPane2);

		getContentPane().add(jPanel3, java.awt.BorderLayout.CENTER);

		pack();
		setLocationRelativeTo(null);
	}// </editor-fold>//GEN-END:initComponents

	private void btnAnalizarActionPerformed(java.awt.event.ActionEvent evt)
	{// GEN-FIRST:event_btnAnalizarActionPerformed

	}// GEN-LAST:event_btnAnalizarActionPerformed

	private void nuevoMouseClicked(java.awt.event.MouseEvent evt)
	{// GEN-FIRST:event_nuevoMouseClicked
		// TODO add your handling code here:
		jTabbedPane1.setTitleAt(0, NuevoArchivo());
	}// GEN-LAST:event_nuevoMouseClicked

	private void nuevoMouseEntered(java.awt.event.MouseEvent evt)
	{// GEN-FIRST:event_nuevoMouseEntered
		// TODO add your handling code here:
		jLabel14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icons/add2.png"))); // NOI18N
		nuevo.setBackground(new java.awt.Color(68, 95, 255));
	}// GEN-LAST:event_nuevoMouseEntered

	private void nuevoMouseExited(java.awt.event.MouseEvent evt)
	{// GEN-FIRST:event_nuevoMouseExited
		// TODO add your handling code here:
		if (acolor == 0)
		{
			nuevo.setBackground(new java.awt.Color(22, 26, 34));
			jLabel14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icons/add.png"))); // NOI18N
		} else
		{
			nuevo.setBackground(new java.awt.Color(240, 240, 240));
			jLabel14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icons/add.png"))); // NOI18N
		}
	}// GEN-LAST:event_nuevoMouseExited

	private void abrirMouseEntered(java.awt.event.MouseEvent evt)
	{// GEN-FIRST:event_abrirMouseEntered
		// TODO add your handling code here:
		jLabel15.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icons/open2.png"))); // NOI18N
		abrir.setBackground(new java.awt.Color(68, 95, 255));
	}// GEN-LAST:event_abrirMouseEntered

	private void abrirMouseExited(java.awt.event.MouseEvent evt)
	{// GEN-FIRST:event_abrirMouseExited
		// TODO add your handling code here:
		if (acolor == 0)
		{
			abrir.setBackground(new java.awt.Color(22, 26, 34));
			jLabel15.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icons/open.png"))); // NOI18N
		} else
		{
			abrir.setBackground(new java.awt.Color(240, 240, 240));
			jLabel15.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icons/open.png"))); // NOI18N
		}
	}// GEN-LAST:event_abrirMouseExited

	private void guardarMouseEntered(java.awt.event.MouseEvent evt)
	{// GEN-FIRST:event_guardarMouseEntered
		// TODO add your handling code here:
		jLabel16.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icons/save2.png"))); // NOI18N
		guardar.setBackground(new java.awt.Color(68, 95, 255));
	}// GEN-LAST:event_guardarMouseEntered

	private void guardarMouseExited(java.awt.event.MouseEvent evt)
	{// GEN-FIRST:event_guardarMouseExited
		// TODO add your handling code here:

		if (acolor == 0)
		{
			guardar.setBackground(new java.awt.Color(22, 26, 34));
			jLabel16.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icons/save.png"))); // NOI18N
		} else
		{
			guardar.setBackground(new java.awt.Color(240, 240, 240));
			jLabel16.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icons/save.png"))); // NOI18N
		}
	}// GEN-LAST:event_guardarMouseExited

	private void jFileChooser1ActionPerformed(java.awt.event.ActionEvent evt)
	{// GEN-FIRST:event_jFileChooser1ActionPerformed
		// TODO add your handling code here:
	}// GEN-LAST:event_jFileChooser1ActionPerformed

	private void abrirMouseClicked(java.awt.event.MouseEvent evt)
	{// GEN-FIRST:event_abrirMouseClicked
		// TODO add your handling code here:
		txtEntrada.setText(abrirArchivo());
	}// GEN-LAST:event_abrirMouseClicked

	private void guardarMouseClicked(java.awt.event.MouseEvent evt)
	{// GEN-FIRST:event_guardarMouseClicked
		// TODO add your handling code here:
		jTabbedPane1.setTitleAt(0, guardarArchivo());
	}// GEN-LAST:event_guardarMouseClicked

	private void ejecutarMouseExited(java.awt.event.MouseEvent evt)
	{// GEN-FIRST:event_ejecutarMouseExited
		// TODO add your handling code here:
		if (acolor == 0)
		{
			ejecutar.setBackground(new java.awt.Color(22, 26, 34));
			jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icons/run1.png"))); // NOI18N
		} else
		{
			ejecutar.setBackground(new java.awt.Color(240, 240, 240));
			jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icons/run1.png"))); // NOI18N
		}
	}// GEN-LAST:event_ejecutarMouseExited

	private void ejecutarMouseEntered(java.awt.event.MouseEvent evt)
	{// GEN-FIRST:event_ejecutarMouseEntered
		// TODO add your handling code here:
		jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icons/run2.png"))); // NOI18N
		ejecutar.setBackground(new java.awt.Color(229, 187, 5));
	}// GEN-LAST:event_ejecutarMouseEntered

	private void AlternarColor(Color cbg1, Color cbg2, Color ctf, Color cf)
	{
		nuevo.setBackground(cbg2);
		abrir.setBackground(cbg2);
		guardar.setBackground(cbg2);

		ejecutar.setBackground(cbg2);

		jPanel1.setBackground(cbg2);
		jPanel3.setBackground(cbg2);
		txtAccion.setBackground(ctf);
		txtConsola.setBackground(ctf);
		txtEntrada.setBackground(ctf);
		txtPila.setBackground(ctf);
		txtResultado.setBackground(ctf);
		txtEnt.setBackground(ctf);
		txtAccion.setForeground(cf);
		txtConsola.setForeground(cf);
		txtEnt.setForeground(cf);
		txtEntrada.setForeground(cf);
		txtPila.setForeground(cf);
		txtResultado.setForeground(cf);
	}

	private String abrirArchivo()
	{
		String aux = "";
		String texto = "";
		try
		{
			/** llamamos el metodo que permite cargar la ventana */
			JFileChooser file = new JFileChooser();
			FileFilter filter = new FileNameExtensionFilter("JDI CODE", "jdi");
			file.setFileFilter(filter);
			file.showOpenDialog(this);
			/** abrimos el archivo seleccionado */
			File abre = file.getSelectedFile();
			jTabbedPane1.setTitleAt(0, abre.getName());

			/**
			 * recorremos el archivo, lo leemos para plasmarlo en el area de texto
			 */
			if (abre != null)
			{
				FileReader archivos = new FileReader(abre);
				BufferedReader lee = new BufferedReader(archivos);
				while ((aux = lee.readLine()) != null)
				{
					texto += aux + "\n";
				}
				lee.close();
			}
		} catch (IOException ex)
		{
			JOptionPane.showMessageDialog(null, ex + "" + "\nNo se ha encontrado el archivo", "ADVERTENCIA!!!",
					JOptionPane.WARNING_MESSAGE);
		}
		return texto;// El texto se almacena en el JTextArea
	}

	public String guardarArchivo()
	{
		try
		{
			String nombre = "";
			JFileChooser file = new JFileChooser();
			file.showSaveDialog(this);
			File guarda = file.getSelectedFile();
			if (guarda != null)
			{
				/*
				 * guardamos el archivo y le damos el formato directamente, si queremos que se
				 * guarde en formato doc lo definimos como .doc
				 */
				FileWriter save = new FileWriter(guarda + ".jdi");
				save.write(txtEntrada.getText());
				save.close();
				JOptionPane.showMessageDialog(null, "El archivo se a guardado Exitosamente", "Información",
						JOptionPane.INFORMATION_MESSAGE);
			}
			File f = new File(guarda + ".jdi");
			return f.getName();
		} catch (IOException ex)
		{
			JOptionPane.showMessageDialog(null, "Su archivo no se ha guardado", "Advertencia",
					JOptionPane.WARNING_MESSAGE);
			return "unnamed.jdi";
		}
	}

	public String NuevoArchivo()
	{
		try
		{
			txtEntrada.setText("");
			String nombre = "";
			JFileChooser file = new JFileChooser();
			file.showSaveDialog(this);
			File guarda = file.getSelectedFile();
			if (guarda != null)
			{
				/*
				 * guardamos el archivo y le damos el formato directamente, si queremos que se
				 * guarde en formato doc lo definimos como .doc
				 */
				FileWriter save = new FileWriter(guarda + ".jdi");
				save.write(txtEntrada.getText());
				save.close();
				JOptionPane.showMessageDialog(null, "El archivo se a guardado Exitosamente", "Información",
						JOptionPane.INFORMATION_MESSAGE);
			}
			File f = new File(guarda + ".jdi");
			return f.getName();
		} catch (IOException ex)
		{
			JOptionPane.showMessageDialog(null, "Su archivo no se ha guardado", "Advertencia",
					JOptionPane.WARNING_MESSAGE);
			return "unnamed.jdi";
		}
	}

	// ANALIZAODR LEXICO
	private void ejecutarMouseClicked(java.awt.event.MouseEvent evt)
	{
		objs = new Sintactico();

		File archivo = new File("archivo.txt");
		PrintWriter escribir;
		lineaerror = 0;
		msj_error = "Prueba";

		try
		{
			escribir = new PrintWriter(archivo);
			escribir.print(txtEntrada.getText());
			escribir.close();
		} catch (FileNotFoundException ex)
		{
			Logger.getLogger(FrmPrincipal.class.getName()).log(Level.SEVERE, null, ex);
		}

		try
		{
			Reader lector = new BufferedReader(new FileReader("archivo.txt"));
			Lexer lexer = new Lexer(lector);
			String resultado = "";

			txtConsola.setText("");
			txtPila.setText("");
			txtEnt.setText("");
			txtAccion.setText("");
			txtResultado.setText("");
			resultado = "";
			textoPila = "";
			textoEnt = "";
			textoAccion = "";
			textoConsola = "";
			int i = 1;
			String aux;

			while (true)
			{
				Tokens tokens = lexer.yylex();

				if (tokens == null)
				{
					txtResultado.setText(resultado);
					return;
				}

				switch (tokens)
				{
					case ERROR:
						textoConsola += "Error léxico en la línea " + i
								+ ": El símbolo NO está definido en el lenguaje!";

						txtConsola.setText(textoConsola);
					break;
					case id:
						ASintactico(tokens + "", i);
						resultado += tokens + " ";
					break;
					case reservada:
						ASintactico(lexer.lexeme + "", i);
						resultado += lexer.lexeme + " ";
					break;
					case nume:
					case numf:
						ASintactico("num", i);
						resultado += tokens + " ";
					break;
					case litcad:
					case litcar:
						aux = lexer.lexeme;
						ASintactico(tokens + "", i);
						resultado += tokens + " ";
					break;
					case salto:
						i++;
						resultado += "\n";
					break;
					case agrupacion:
					case aritmetico:
					case logico:
					case relacional:
					case asignacion:
					case finSentencia:
					case coma:
					case puntos:
						ASintactico(lexer.lexeme, i);
						resultado += lexer.lexeme + " ";
					break;
					case meniq:
					case mayiq:
					case dif:
					case igual:
						aux = lexer.lexeme;
						ASintactico(tokens + "", i);
						resultado += lexer.lexeme + " ";
					break;
				}
			}

		} catch (FileNotFoundException e)
		{
			e.printStackTrace();
		} catch (IOException ex)
		{
			Logger.getLogger(FrmPrincipal.class.getName()).log(Level.SEVERE, null, ex);
		}
	}

	public void ASintactico(String comp, int i)
	{
		boolean b = false;

		if (comp.equals("method") || comp.equals("funtion"))
			com = comp;
		if (com.equals("method") && comp.equals("id"))
		{
			comp = "idp";
			objs.Pila(comp);
			com = "";
			b = true;
		}
		if (comp.equals("endp"))
		{
			objs.Pila(comp);
			objs.Pila("$");
			b = true;
		}
		if (com.equals("funtion") && comp.equals("id"))
		{
			comp = "idf";
			objs.Pila(comp);
			com = "";
			b = true;
		}
		if (!b)
			objs.Pila(comp);

		if (objs.aceptar)
			Imprimir();

		// DETERMINA SI HAY UN ERROR Y LO IMPRIME
		if (objs.tip_error.contains("Error") && !objs.msj_error.equals(msj_error)
				&& !objs.msj_error.contains("Sin errores"))
		{
			textoConsola += objs.tip_error + i + ": " + objs.msj_error + "\n";
			txtConsola.setText(textoConsola);
			msj_error = objs.msj_error;
		}

	}

	public void Imprimir()
	{
		for (int x = 0; x < objs.list_pila.size() - 1; x++)
		{

			textoPila += objs.list_pila.get(x) + "\n";
			txtPila.setText(textoPila);

			textoEnt += objs.list_entrada.get(x) + "\n";
			txtEnt.setText(textoEnt);

			textoAccion += objs.list_accion.get(x) + "\n";
			txtAccion.setText(textoAccion);

			System.out.println(x + ")	" + objs.list_pila.get(x));
			System.out.println(x + ")	" + objs.list_entrada.get(x));
			System.out.println(x + ")	" + objs.list_accion.get(x));
			System.out.println("-----------------------------");

		}

	}

	public void TextoPila(String texto)
	{
		txtPila.setText(texto);
	}

	public static void main(String args[])
	{
		/* Set the Nimbus look and feel */
		// <editor-fold defaultstate="collapsed" desc=" Look and feel setting code
		// (optional) ">
		/*
		 * If Nimbus (introduced in Java SE 6) is not available, stay with the default
		 * look and feel. For details see
		 * http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html
		 */
		try
		{
			for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels())
			{
				if ("Nimbus".equals(info.getName()))
				{
					javax.swing.UIManager.setLookAndFeel(info.getClassName());
					break;
				}
			}
		} catch (ClassNotFoundException ex)
		{
			java.util.logging.Logger.getLogger(FrmPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null,
					ex);
		} catch (InstantiationException ex)
		{
			java.util.logging.Logger.getLogger(FrmPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null,
					ex);
		} catch (IllegalAccessException ex)
		{
			java.util.logging.Logger.getLogger(FrmPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null,
					ex);
		} catch (javax.swing.UnsupportedLookAndFeelException ex)
		{
			java.util.logging.Logger.getLogger(FrmPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null,
					ex);
		}
		// </editor-fold>

		/* Create and display the form */
		java.awt.EventQueue.invokeLater(new Runnable()
		{
			public void run()
			{
				new FrmPrincipal().setVisible(true);
			}
		});
	}

	// Variables declaration - do not modify//GEN-BEGIN:variables
	private javax.swing.JPanel abrir;
	private javax.swing.JButton btnAnalizar;
	private javax.swing.JPanel ejecutar;
	private javax.swing.JPanel guardar;
	private javax.swing.JFileChooser jFileChooser1;
	private javax.swing.JLabel jLabel1;
	private javax.swing.JLabel jLabel14;
	private javax.swing.JLabel jLabel15;
	private javax.swing.JLabel jLabel16;
	private javax.swing.JLabel jLabel2;
	private javax.swing.JLabel jLabel3;
	private javax.swing.JLabel jLabel4;
	private javax.swing.JLabel jLabel5;
	private javax.swing.JLabel jLabel6;
	private javax.swing.JLabel jLabel7;
	private javax.swing.JLabel jLabel8;
	private javax.swing.JLabel jLabel9;
	private javax.swing.JPanel jPanel1;
	private javax.swing.JPanel jPanel10;
	private javax.swing.JPanel jPanel11;
	private javax.swing.JPanel jPanel12;
	private javax.swing.JPanel jPanel13;
	private javax.swing.JPanel jPanel2;
	private javax.swing.JPanel jPanel3;
	private javax.swing.JPanel jPanel4;
	private javax.swing.JPanel jPanel5;
	private javax.swing.JPanel jPanel7;
	private javax.swing.JPanel jPanel8;
	private javax.swing.JPanel jPanel9;
	private javax.swing.JScrollPane jScrollPane1;
	private javax.swing.JScrollPane jScrollPane2;
	private javax.swing.JScrollPane jScrollPane3;
	private javax.swing.JScrollPane jScrollPane4;
	private javax.swing.JScrollPane jScrollPane6;
	private javax.swing.JScrollPane jScrollPane7;
	private javax.swing.JTabbedPane jTabbedPane1;
	private javax.swing.JTabbedPane jTabbedPane2;
	private javax.swing.JPanel nuevo;
	private javax.swing.JTable tablaS;
	private javax.swing.JTextArea txtAccion;
	private javax.swing.JTextArea txtConsola;
	private javax.swing.JTextArea txtEnt;
	private javax.swing.JTextArea txtEntrada;
	private javax.swing.JTextArea txtPila;
	private javax.swing.JTextArea txtPila1;
	private javax.swing.JTextArea txtResultado;
	// End of variables declaration//GEN-END:variables
}
