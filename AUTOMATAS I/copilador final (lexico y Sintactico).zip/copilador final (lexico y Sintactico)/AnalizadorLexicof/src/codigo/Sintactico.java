/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package codigo;

import java.util.EmptyStackException;
import java.util.LinkedList;
import java.util.Stack;

public class Sintactico
{
	String pila_error = "";
	Stack<String> pila = new Stack<String>();
	int renglones = 0, columnas = 0;
	Boolean ban = true, aceptar = false, ban_error = false;
	String cont, cadenaPila, msj, tip_error = "Libre", msj_error = "", txtPila = "";
	String encabezadosRenglones[] = { "prog", "dec", "sigid", "modulos", "proc", "fun", "tiporetorno", "list-arg",
			"siglist", "list-param", "sig-param", "sentencias", "sentencia", "sigif", "L", "L’", "R", "R’", "E",
			"E’", "T", "T’", "F", "$" };
	String encabezadosColumnas[] = { "id", "num", "(", ")", "litcad", "litcar", "+", "-", "*", "/", "=", "<", ">",
			"meniq", "mayiq", "dif", "igual", "!", "&", "|", "true", "false", "if", "while", "repeat", "else", "then",
			"do", "endif", "endwhile", "program", "int", "float", "char", "string", "boolean", "read", "write", ",",
			"method", "funtion", "endm", "endf", "endp", "idm", "idf", "return", "$", ";", "call", "until" };
	String matriz[][] = {
			// { "id", 0 "num", 1 "(", 2 ")", 3 "litcad", 4 "litcar", 5 "+", 6 "-", 7 "*", 8
			// "/", 9 "=", 10 "<", 11 ">", 12 "meniq",13 "mayiq",14 "dif", 15 "igual", 16
			// "!", 17 "&", 18 "|", 19 "true", 20 "false", 21 "if", 22 "while", 23 "repeat",
			// 24 "else",25 "then", 26 "do", 27 "endif", 28 "endwhile", 29 "program", 30
			// "int", 31 "float", 32 "char", 33 "string", 34 "boolean", 35 "read", 36
			// "write", 37 ",", 38 "method", 39 "funtion", 40 "endm", 41 "endf", 42 "endp",
			// 43 "idm", 44 "idf", 45 "return", 46 "$" 47 ";" 48 "call" 49 "until" 50};
			/* prog 0 */ { "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ",
					"saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ",
					"saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ",
					"saltar ", "saltar ", "saltar ", "saltar ", "program id ; modulos dec sentencias endp ", "saltar ",
					"saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ",
					"saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "sacar ", "saltar ", "saltar ",
					"saltar " },
			/* dec 1 */ { "ç ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ",
					"saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ",
					"saltar ", "saltar ", "saltar ", "saltar ", "ç ", "saltar ", "saltar ", "saltar ", "saltar ",
					"saltar ", "saltar ", "saltar ", "saltar ", "int id sigid ; dec ", "float id sigid ; dec ",
					"char id sigid ; dec ", "string id sigid ; dec ", "boolean id sigid ; dec ", "ç ", "ç ",
					"saltar ", "saltar ", "saltar ", "ç ", "saltar ", "ç ", "saltar ", "saltar ", "saltar ", "sacar ",
					"saltar ", "saltar ", "saltar " },
			/* sigid 2 */ { "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ",
					"saltar ", "saltar ", "= E sigid ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ",
					"saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ",
					"saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "ç ", "saltar ", "saltar ",
					"saltar ", "saltar ", "saltar ", "saltar ", ", id siglist ", "saltar ", "saltar ", "saltar ",
					"saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "sacar ", "ç ", "saltar ", "saltar " },
			/* modulos 3 */ { "ç ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ",
					"saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ",
					"saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "ç ", "ç ", "ç ", "saltar ", "saltar ",
					"saltar ", "saltar ", "saltar ", "saltar ", "ç ", "ç ", "ç ", "ç ", "ç ", "saltar ", "saltar ",
					"saltar ", "proc modulos ", "fun modulos ", "ç ", "saltar ", /* aqui es saltar */"ç ", "saltar ",
					"saltar ", "saltar ", "sacar ", "saltar ", "saltar ", "saltar " },
			/* proc 4 */ { "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ",
					"saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ",
					"saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ",
					"saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ",
					"saltar ", "saltar ", "saltar ", "saltar ", "method idp ( list-arg ) dec sentencias endm ",
					"saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "sacar ", "saltar ",
					"saltar ", "saltar " },
			/* fun 5 */ { "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ",
					"saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ",
					"saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ",
					"saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ",
					"saltar ", "saltar ", "saltar ", "saltar ", "saltar ",
					"funtion idf ( list-arg ) : tiporetorno dec sentencias endf ", "saltar ", "saltar ", "saltar ",
					"saltar ", "saltar ", "saltar ", "sacar ", "saltar ", "saltar ", "saltar " },
			/* tiporetorno 6 */ { "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ",
					"saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ",
					"saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ",
					"saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "int ", "float ", "char ",
					"string ", "boolean ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ",
					"saltar ", "saltar ", "saltar ", "saltar ", "sacar ", "saltar ", "saltar ", "saltar " },
			/* list-arg 7 */ { "saltar ", "saltar ", "saltar ", "ç ", "saltar ", "saltar ", "saltar ", "saltar ",
					"saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ",
					"saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ",
					"saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "int id siglist ", "float id siglist ",
					"char id siglist ", "string id siglist ", "boolean id siglist ", "saltar ", "saltar ", "saltar ",
					"saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "sacar ",
					"ç ", "saltar ", "saltar " },
			/* siglist 8 */ { "saltar ", "saltar ", "saltar ", "ç ", "saltar ", "saltar ", "saltar ", "saltar ",
					"saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ",
					"saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ",
					"saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ",
					"saltar ", "saltar ", "saltar ", ", list-arg ", "saltar ", "saltar ", "saltar ", "saltar ",
					"saltar ", "saltar ", "saltar ", "saltar ", "sacar ", "ç ", "saltar ", "saltar " },
			/* list-param 9 */ { "L sig-param ", "L sig-param ", "L sig-param ", "ç ", "L sig-param ", "L sig-param ",
					"saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ",
					"saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "L sig-param ", "L sig-param ", "saltar ",
					"saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ",
					"saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ",
					"saltar ", "saltar ", "saltar ", "saltar ", "L sig-param ", "saltar ", "sacar ", "saltar ",
					"saltar ", "saltar " },
			/* sig-param 10 */ { "saltar ", "saltar ", "saltar ", "ç ", "saltar ", "saltar ", "saltar ", "saltar ",
					"saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ",
					"saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ",
					"saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ",
					"saltar ", "saltar ", "saltar ", ", L sig-param ", "saltar ", "saltar ", "saltar ", "saltar ",
					"saltar ", "saltar ", "saltar ", "saltar ", "sacar ", "saltar ", "saltar ", "saltar " },
			/* sentencias 11 */ { "sentencia sentencias ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ",
					"saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ",
					"saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ",
					"sentencia sentencias ", "sentencia sentencias ", "sentencia sentencias ", "ç ", "saltar ",
					"saltar ", "ç ", "ç ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ",
					"F sentencias ", "sentencia sentencias ", "saltar ", "saltar ", "saltar ", "ç ", "ç ", "ç ",
					"sentencia sentencias ", "saltar ", "sentencia sentencias ", "ç ", "saltar ",
					"sentencia sentencias ", "ç " },
			/* sentencia 12 */ { "id = L ; ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ",
					"saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ",
					"saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ",
					"if ( L ) then sentencias sigif endif ", "while ( L ) do sentencias endwhile ",
					"repeat sentencias until ( L ) ; ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ",
					"saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ",
					"write ( list-param ) ; ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ",
					"idp ( list-param ) ; ", "saltar ", "return L ; ", "sacar ", "saltar ",
					"call id ( L sig-param ) ; ", "saltar " },
			/* sigif 13 */ { "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ",
					"saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ",
					"saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ",
					"else sentencias ", "saltar ", "saltar ", "ç ", "saltar ", "saltar ", "saltar ", "saltar ",
					"saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ",
					"saltar ", "ç ", "saltar ", "saltar ", "saltar ", "ç ", "saltar ", "saltar ", "saltar " },
			/* L 14 */ { "R L’ ", "R L’ ", "R L’ ", "ç ", "R L’ ", "R L’ ", "saltar ", "saltar ", "saltar ",
					"saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "R L’ ",
					"saltar ", "saltar ", "R L’ ", "R L’ ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ",
					"saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ",
					"saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ",
					"R L’ ", "saltar ", "ç ", "saltar ", "R L’ ", "saltar " },
			/* L’ 15 */ { "saltar ", "saltar ", "saltar ", "ç ", "saltar ", "saltar ", "ç ", "ç ", "ç ", "ç ",
					"saltar ", "ç ", "ç ", "ç ", "ç ", "ç ", "ç ", "saltar ", "& R L’ ", "| R L’ ", "saltar ",
					"saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "ç ", "ç ", "saltar ", "saltar ",
					"saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "ç ",
					"saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "ç ",
					"ç ", "saltar ", "saltar " },
			/* R 16 */ { "E R’ ", "E R’ ", "E R’ ", "saltar ", "E R’ ", "E R’ ", "saltar ", "saltar ",
					"saltar ", "saltar ", "saltar ", "saltar ", "saltar  ", "saltar ", "saltar ", "saltar ", "saltar ",
					"E R’ ", "ç ", "ç ", "E R’ ", "E R’ ", "saltar ", "saltar ", "saltar ", "saltar ", "ç ",
					"ç ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ",
					"saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ",
					"E R’ ", "saltar ", "ç ", "saltar ", "E R’ ", "saltar " },
			/* R’ 17 */ { "saltar ", "saltar ", "saltar ", "ç ", "saltar ", "saltar ", "ç ", "ç ", "ç ", "ç ",
					"saltar ", "< E ", "> E ", "meniq E ", "mayiq E ", "dif E ", "igual E ", "saltar ", "ç ", "ç ",
					"saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "ç ", "ç ", "saltar ",
					"saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ",
					"ç ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ",
					"ç ", "ç ", "saltar ", "saltar " },
			/* E 18 */ { "T E’ ", "T E’ ", "T E’ ", "saltar ", "T E’ ", "T E’ ", "saltar ", "saltar ",
					"saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ",
					"T E’ ", "saltar ", "saltar ", "T E’ ", "T E’ ", "saltar ", "saltar ", "saltar ", "saltar ",
					"saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ",
					"saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ",
					"saltar ", "T E’ ", "saltar ", "sacar ", "saltar ", "T E’ ", "saltar " },
			/* E’ 19 */ { "saltar ", "saltar ", "saltar ", "ç ", "saltar ", "saltar ", "+ T E’ ", "- T E’ ",
					"ç ", "ç ", "saltar ", "ç ", "ç ", "ç ", "ç ", "ç ", "ç", "saltar ", "ç ", "ç ",
					"saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "ç ", "ç ", "saltar ",
					"saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ",
					"ç ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ",
					"ç ", "ç ", "saltar ", "saltar " },
			/* T 20 */ { "F T’ ", "F T’ ", "F T’ ", "saltar ", "F T’ ", "F T’ ", "saltar ", "saltar ",
					"saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ",
					"F T’ ", "saltar ", "saltar ", "F T’ ", "F T’ ", "saltar ", "saltar ", "saltar ", "saltar ",
					"saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ",
					"saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ",
					"saltar ", "F T’ ", "saltar ", "sacar ", "saltar ", "F T’ ", "saltar " },
			/* T’ 21 */ { "saltar ", "saltar ", "saltar ", "ç ", "saltar ", "saltar ", "ç ", "ç ", "* F T’ ",
					"/ F T’ ", "saltar ", "ç ", "ç ", "ç ", "ç ", "ç ", "ç ", "saltar ", "ç ", "ç ",
					"saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "ç ", "ç ", "saltar ",
					"saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ",
					"ç ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ",
					"ç ", "ç ", "saltar ", "saltar " },
			/* F 22 */ { "id ", "num ", "( L ) ", "saltar ", "litcad ", "litcar ", "saltar ", "saltar ", "saltar ",
					"saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "! L ",
					"saltar ", "saltar ", "true ", "false ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ",
					"saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ",
					"read ( list-param ) ; ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ",
					"saltar ", "saltar ", "idf ( list-param ) ", "saltar ", "sacar ", "saltar ",
					"call id ( L sig-param ) ", "saltar " },
			/* $ 23 */ { "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ",
					"saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ",
					"saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ",
					"saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ",
					"saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ", "saltar ",
					"saltar ", "saltar ", "saltar ", "aceptar ", "saltar ", "saltar ", "saltar " } };

	LinkedList<String> list_pila = new LinkedList<String>();
	LinkedList<String> list_entrada = new LinkedList<String>();
	LinkedList<String> list_accion = new LinkedList<String>();

	public Sintactico()
	{
		if (ban)
		{
			ban = false;
			pila.push("$");
			pila.push("prog");
			list_pila.add(pila + "");
		}
	}

	public void Pila(String token)
	{
		try
		{
			list_entrada.add(token);

			// VALIDA SI LA SIMA DE LA PILA CONCUERDA CON EL TOKEN
			if (token.equals(pila.peek()))
				if (token.equals("$")) // SI CONCUERDA CON UN "$" LA CADENA ES ACEPATA
				{
					aceptar = true;
					list_accion.add("ACEPTADA!!!!");
					pila.pop();
					list_pila.add(pila + "");

				} else
					this.Concuerda();
			else
			{
				// TERMINA EL SICLO HASTA QUE EL TOKEN ENCUENTRE UNA ACCION
				// COMO QUE CONCUERDE CON EL VALOR DE LA SIMA DE LA PILA, SE GENERE UN ERROR,
				// LA ACCION SACAR DE LA PILA 0 CADENA VACIA "�"
				do
				{
					this.Columnas(token);
					this.Renglones();

					if (matriz[renglones][columnas].equals("saltar "))
					{
						list_accion.add("SALTAR");
						list_pila.add(pila + "");
						BuscarError();
						break;

					} else if (matriz[renglones][columnas].equals("sacar "))
					{

						list_accion.add("SACAR");
						pila.pop();
						list_pila.add(pila + "");
						BuscarError();
						this.Pila(token);
						break;

					} else if (matriz[renglones][columnas].equals("ç "))
					{

						list_accion.add("ç");
						pila.pop();
						list_pila.add(pila + "");
						this.Pila(token);
						break;

					} else if (matriz[renglones][columnas].equals("aceptar "))
					{
						aceptar = true;
						list_accion.add("ACEPTADA!");
						list_pila.add(pila + "");
						break;

					} else
					{
						// SE DETERMINA QUE HAY UNA ACCION PARA APILAR
						list_accion.add(matriz[renglones][columnas]);

						Stack<String> pilaaux = new Stack<>();
						String pal = "";
						pila.pop();

						// ALMACENA LO QUE REGRESA LA TABLA EN LA PILA AUXILIAR
						for (int j = 0; j < matriz[renglones][columnas].length(); j++)
							if (matriz[renglones][columnas].charAt(j) != ' ')
								pal += matriz[renglones][columnas].charAt(j) + "";
							else
							{
								pilaaux.push(pal);
								pal = "";
							}

						// SE VACIA LA PILA AUXILIAR PARA GUARDAR EN LA PILA PRINCIPAL
						do
							pila.push(pilaaux.pop());
						while (!pilaaux.isEmpty());

						list_pila.add(pila + "");
						list_entrada.add(token);

						// DETERMINA SI CONCUERDA CON LA SIMA DE LA PILA Y SI ES ASI SALE DEL SICLO
						if (token.equals(pila.peek()))
						{
							this.Concuerda();
							break;
						}
					}
				} while (aceptar == false && !token.equals(pila.peek()));
			}
		} catch (EmptyStackException e)
		{
			e.printStackTrace();
		}
	}

	public void Concuerda()
	{
		list_accion.add("CONCUERDA");
		pila.pop();
		list_pila.add(pila + "");
	}

	public int Renglones()
	{
		for (int i = 0; i < encabezadosRenglones.length; i++)
			if (encabezadosRenglones[i].equals(pila.peek()))
			{
				renglones = i;
				break;
			}
		return renglones;
	}

	public int Columnas(String token)
	{
		for (int i = 0; i < encabezadosColumnas.length; i++)
			if (token.equals(encabezadosColumnas[i]))
			{
				columnas = i;
				break;
			}
		return columnas;
	}

	private void BuscarError()
	{
			tip_error = "Error sintáctico en la línea ";
			switch (pila.peek())
			{
				// ENCABEZADO RENGLONES
				case "prog":
					msj_error = ". El programa debe iniciar con la palabra reservada: program.";
				break;
				case "dec":
					msj_error = ". Esperaba una declaración!";
				break;
				case "sigid":
					msj_error = ". Esperaba un ID!";
				break;
				case "tiporetorno":
					msj_error = ". Esperaba el tipo de retorno de la función!";
				break;
				case "list-arg":
					msj_error = ". Esperaba la lista de los argumentos!";
				break;
				case "siglist":
					msj_error = ". Esperaba un argumento!";
				break;
				case "list-param":
					msj_error = ". Esperaba la lista de los parámetros!";
				break;
				case "sig-param":
					msj_error = ". Esperaba un parámetro!";
				break;
				case "sentencias":
					msj_error = ". Esperaba una sentencia!";
				break;
				case "endf":
					msj_error = ". Esperaba el final de la función!";
				break;
				case "endp":
					msj_error = ". Esperaba el final del programa!";
				break;
				case "endm":
					msj_error = ". Esperaba el final del método!";
				break;
				case "sigif":
					msj_error = ". Esperaba un if!";
				break;
				case "L":
				case "R":
				case "E":
				case "T":
					msj_error = ". Esperaba una expresión!";
				break;
				case "L’":
				case "R’":
				case "E’":
				case "T’":
					msj_error = ". Esperaba un operador!";
				break;
				
				// ENCABEZADO COLUMNAS
				case "id":
					msj_error = "Esperaba una id";
				break;
				case "num":
					msj_error = "Esperaba un numero";
				break;
				case "(":
					msj_error = "Esperaba un par�ntesis que abre";
				break;
				case ")":
					msj_error = "Esperaba un par�ntesis que cierra";
				break;
				case "litcad":
					msj_error = "Esperaba una literal cadena";
				break;
				case "litcar":
					msj_error = "Esperaba un literal caracter";
				break;
				case "+":
					msj_error = "Esperaba un operador suma ";
				break;
				case "-":
					msj_error = " Esperaba un operador resta ";
				break;
				case "*":
					msj_error = "Esperaba un operador multiplicaci�n ";
				break;
				case "/":
					msj_error = "Esperaba un operador divisi�n";
				break;
				case "=":
					msj_error = " Esperaba un operador igual ";
				break;
				case "<":
					msj_error = "Esperaba un operador menor qu�";
				break;
				case ">":
					msj_error = "Esperaba un operador mayor qu�";
				break;
				case "meniq":
					msj_error = " Esperaba un menor igual que";
				break;
				case "mayiq":
					msj_error = " Esperaba un mayor igual que";
				break;
				case "dif":
					msj_error = " Esperaba�un�dif�";
				break;
				case "igual":
					msj_error = "Esperaba un igual";
				break;
				case "!":
					msj_error = "Esperaba un !";
				break;
				case "&":
					msj_error = "Esperaba un &";
				break;
				case "|":
					msj_error = "Esperaba un |";
				break;
				case "true":
					msj_error = "Esperaba un true";
				break;
				case "false":
					msj_error = "Esperaba un false";
				break;
				case "if":
					msj_error = "Esperaba un if";
				break;
				case "while":
					msj_error = "Esperaba un while";
				break;
				case "repeat":
					msj_error = "Esperaba un repeat";
				break;
				case "else":
					msj_error = "Esperaba un else";
				break;
				case "then":
					msj_error = "Esperaba un then";
				break;
				case "do":
					msj_error = "Esperaba un do";
				break;
				case "endif":
					msj_error = "Esperaba un endif ";
				break;
				case "endwhile":
					msj_error = "Esperaba un endwhile ";
				break;
				case "program":
					msj_error = "Esperaba un program ";
				break;
				case "int":
					msj_error = "Esperaba un int";
				break;
				case "float":
					msj_error = "Esperaba un float";
				break;
				case "char":
					msj_error = "Esperaba un char ";
				case "string":
					msj_error = "Esperaba un string ";
				break;
				case "boolean":
					msj_error = "Esperaba un boolean ";
				break;
				case "read":
					msj_error = "Esperaba un read";
				break;
				case "write":
					msj_error = "Esperaba un write";
				break;
				case ",":
					msj_error = "Esperaba un ,";
				break;
				case "method":
					msj_error = "Esperaba un method ";
				break;
				case "funtion":
					msj_error = "Esperaba un funtion";
				break;
				case "idm":
					msj_error = "Esperaba un idm ";
				break;
				case "idf":
					msj_error = "Esperaba un idf ";
				break;
				case "return":
					msj_error = "Esperaba un return ";
				break;
				case ";":
					msj_error = "Esperaba un ;";
				break;
				case "call":
					msj_error = "Esperaba un call";
				break;
				case "until":
					msj_error = "Esperaba�un�until";
				break;
			}
	}

	public String MensajeError()
	{
		return tip_error;
	}

	public String msj_error()
	{
		return msj_error;
	}
}
